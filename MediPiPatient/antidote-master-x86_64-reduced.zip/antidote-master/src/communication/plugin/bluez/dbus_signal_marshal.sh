glib-genmarshal --header --body ChannelConnected.list > signal_marshall.h
