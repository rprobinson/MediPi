#ifndef _TRANS_PLUGIN_SAMPLE_OXIMETER_H
#define _TRANS_PLUGIN_SAMPLE_OXIMETER_H

#include <src/trans/trans.h>

void trans_plugin_oximeter_register();

#endif
