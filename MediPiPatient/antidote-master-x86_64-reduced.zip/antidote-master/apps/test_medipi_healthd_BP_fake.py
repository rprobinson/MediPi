#!/usr/bin/python

# RRobinson MediPi usage - 	Added flushes to force data to be sent from script whilst reading from within java program
# 							Added exit statements as only wanted one reading at a time

import sys
import time

print "START"
sys.stdout.flush()
print "Starting..."
sys.stdout.flush()
print "Configuring..."
sys.stdout.flush()
print "Waiting..."
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Connected from addr 00:22:58:38:98:c7, dev /com/signove/health/device/2"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Associated dev /com/signove/health/device/2: XML with 1546 bytes"
sys.stdout.flush()
print "System ID: 00220922583898C7"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Configuration: XML with 4281 bytes"
sys.stdout.flush()
print ""
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Configuration"
sys.stdout.flush()
print "	Numeric  unit  3872"
sys.stdout.flush()
print "	Numeric  unit  2720"
sys.stdout.flush()
print "	Numeric  unit  512"
sys.stdout.flush()
print "Setting time to now"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "DeviceAttributes dev /com/signove/health/device/2"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Device Attributes"
sys.stdout.flush()
print "	Manufacturer: OMRON HEALTHCARE Model: HEM-7081-IT"
sys.stdout.flush()
print "	System ID 00220922583898C7"
sys.stdout.flush()
print "	Specializations: 0x1007"
sys.stdout.flush()
print "	Device config ID 16384"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "MeasurementData dev /com/signove/health/device/2"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Measurement"
sys.stdout.flush()
time.sleep(2)  
print "	(125.000000,80.000000,95.000000) mmHg @ 2017-09-07T17:47:25.000Z"
sys.stdout.flush()
print "	74.000000 bpm @ 2017-09-07T17:47:25.000Z"
sys.stdout.flush()
print "	0.000000  @ 2017-09-07T17:47:25.000Z"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "MeasurementData dev /com/signove/health/device/2"
sys.stdout.flush()
print ""
print "Measurement"
sys.stdout.flush()
time.sleep(2)  
print "	(126.000000,81.000000,96.000000) mmHg @ 2017-09-07T17:37:25.000Z"
sys.stdout.flush()
print "	75.000000 bpm @ 2017-09-07T17:37:25.000Z"
sys.stdout.flush()
print "	0.000000  @ 2017-09-07T17:37:25.000Z"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "MeasurementData dev /com/signove/health/device/2"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Measurement"
sys.stdout.flush()
print "	(127.000000,82.000000,97.000000) mmHg @ 2017-09-07T17:38:25.000Z"
sys.stdout.flush()
print "	76.000000 bpm @ 2017-09-07T17:38:25.000Z"
sys.stdout.flush()
print "	256.000000  @ 2017-09-07T17:38:25.000Z"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Disassociated dev /com/signove/health/device/2"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Disconnected /com/signove/health/device/2"
sys.stdout.flush()
print "END"
sys.stdout.flush()




