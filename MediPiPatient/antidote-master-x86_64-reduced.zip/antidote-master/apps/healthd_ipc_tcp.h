#ifndef HEALTHD_IPC_TCP_
#define HEALTHD_IPC_TCP_

#include "healthd_ipc.h"

void healthd_ipc_tcp_init(healthd_ipc *ipc);

#endif
