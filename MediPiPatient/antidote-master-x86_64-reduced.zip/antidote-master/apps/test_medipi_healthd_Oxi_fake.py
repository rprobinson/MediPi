#!/usr/bin/python

# RRobinson MediPi usage - 	Added flushes to force data to be sent from script whilst reading from within java program
# 							Added exit statements as only wanted one reading at a time

import sys
import time

print "START"
sys.stdout.flush()
print "Starting..."
sys.stdout.flush()
print "Configuring..."
sys.stdout.flush()
print "Waiting..."
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Connected from addr 00:1c:05:00:ad:5f, dev /com/signove/health/device/1"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Associated dev /com/signove/health/device/1: XML with 1391 bytes"
sys.stdout.flush()
print "System ID: 001C05010000AD5F"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Configuration: XML with 3126 bytes"
sys.stdout.flush()
print ""
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Configuration"
sys.stdout.flush()
print "	Numeric  unit  544"
sys.stdout.flush()
print "	Numeric  unit  2720"
sys.stdout.flush()
print "Setting time to now"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "DeviceAttributes dev /com/signove/health/device/1"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Device Attributes"
sys.stdout.flush()
print "	Manufacturer: Nonin Medical, Inc. Model: Model 9560"
sys.stdout.flush()
print "	System ID 001C05010000AD5F"
sys.stdout.flush()
print "	Specializations: 0x1004"
sys.stdout.flush()
print "	Device config ID 401"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "MeasurementData dev /com/signove/health/device/1"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Measurement"
sys.stdout.flush()
time.sleep(2)  
print "	98.000000 % @ 2017-09-07T18:01:25.000Z"
sys.stdout.flush()
print "	69.000000 bpm @ 2017-09-07T18:01:25.000Z"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "MeasurementData dev /com/signove/health/device/1"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Measurement"
sys.stdout.flush()
print "	99.000000 % @ 2017-09-07T17:58:25.000Z"
sys.stdout.flush()
print "	70.000000 bpm @ 2017-09-07T17:58:25.000Z"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Disassociated dev /com/signove/health/device/1"
sys.stdout.flush()
print ""
sys.stdout.flush()
print "Disconnected /com/signove/health/device/1"
sys.stdout.flush()
print "END"
sys.stdout.flush()




