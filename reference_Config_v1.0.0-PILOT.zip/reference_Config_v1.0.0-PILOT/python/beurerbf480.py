#!/usr/bin/env python
 
"""
ID 04d9:8010 Holtek Semiconductor, Inc. 
Python script to download data from the Beurer BF-480
Richard Robinson rick@robinsonhq.com based upon https://usb2me.wordpress.com/2013/02/03/beurer-bg64/
Version 1.1
05.01.2016
"""
import os
import usb.core
import usb.util as util
from array import array
import sys
from optparse import OptionParser, make_option
import pickle
from struct import unpack
import argparse
 
dev = None
 
VID = 0x04d9
PID = 0x8010
 
# define HID constants
 
REQ_HID_GET_REPORT   = 0x01
REQ_HID_GET_IDLE     = 0x02
REQ_HID_GET_PROTOCOL = 0x03
 
REQ_HID_SET_REPORT   = 0x09
REQ_HID_SET_IDLE     = 0x0A
REQ_HID_SET_PROTOCOL = 0x0B
 
HID_REPORT_TYPE_INPUT   = 1<<8
HID_REPORT_TYPE_OUTPUT  = 2<<8
HID_REPORT_TYPE_FEATURE = 3<<8
 
def openDev():
    global dev
    dev = usb.core.find(idVendor=VID, idProduct=PID)
    if dev is None:
        print >> sys.stdout, "Device not Found - is the scale plugged into the USB port?"
        sys.stdout.flush()
    if dev.is_kernel_driver_active(0):
        dev.detach_kernel_driver(0)
    dev.set_configuration() # do reset and set active conf. Must be done before claim.
#    util.claim_interface(dev, None)
#    print >> sys.stdout, "Configuration set"
 
def setReport(reportId, data):
    r = dev.ctrl_transfer(
        util.build_request_type(util.CTRL_OUT, util.CTRL_TYPE_CLASS, util.CTRL_RECIPIENT_INTERFACE), # bmRequestType,
        REQ_HID_SET_REPORT,
        HID_REPORT_TYPE_OUTPUT | reportId,
        0,                 # feature_interface_num
        data,              # data
        3000               # timeout (1000 was too small for C_FREE)
    )
    return r
 
def read():
    openDev()
    try:
        dev.read(0x81,128) #flush 
    except usb.core.USBError:
        pass
     
    setReport(9, array('B',(0x10,0,0,0,0,0,0,0)))
#    print >> sys.stdout, "Report set"
 
    # Every user can have upto 6 variables
    # and additional 4*128 for user data
    r = []
    for i in xrange(60+4):
        x = dev.read(0x81,128)
        if not x:
            print >> sys.stdout, "Read failed"
            sys.stdout.flush()
            exit(1)
        print >> sys.stdout, "LOOP:",i
        sys.stdout.flush()
        r.append(x)    
 
    # Each variable can have upto 64 values
    frmt = "!" + "H"*64
    s = []
    for i in xrange(60) :
        x = unpack(frmt, r[i])
        s.append(x)
    return s
 
def printUser(s, user):
    # Transpose from 6x64 to 64x6 and format
 
    j = 6*user
    for i in xrange(64):
        x = s[j+4][i] # date
        y = s[j+5][i] # time
        if not x:
           break
        form ="DATA:{:d}-{:02d}-{:02d}" + args.delimeter + "{:02d}:{:02d}" + args.delimeter + "{}" + args.delimeter + "{:.1f}" + args.delimeter + "{:.1f}" + args.delimeter + "{:.1f}" + args.delimeter + "{:.1f}"
        print form.format(
           1920+(x>>9), x>>5&0xf, x&0x1f,y>>8,y&0xff,args.user,
           s[j+0][i]/10., s[j+1][i]/10., s[j+2][i]/10., s[j+3][i]/10.)
 
def main():
    #Direct all stderr to null in order that the calling java prog will only see the data and the "error strings" I generate
    f = open(os.devnull, 'w')
    sys.stderr = f

    parser = argparse.ArgumentParser(description="beurerbf480.py - Beurer BF-480 Diagnostic Scale data downloader (c) 2015 rick@robinsonhq.com")
    parser.add_argument("user", help="Specify for which the user the data should be downloaded", choices=["1", "2", "3", "4", "5", "6", "7", "8", "9","10"])
    parser.add_argument("delimeter", help="specify the delimeter to be used to separate the data")
    global args
    args=parser.parse_args()

    print >> sys.stdout, "START"
    sys.stdout.flush()
    s = read()
    user = int(args.user)-1
    printUser(s, user)
    print >> sys.stdout, "END"
    sys.stdout.flush()


if __name__ == '__main__':
    main()
