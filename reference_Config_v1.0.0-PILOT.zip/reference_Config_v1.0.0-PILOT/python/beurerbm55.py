#!/usr/bin/env python
 
"""
ID 0C45:7406 Sonix 
Python script to download data from the Beurer BM-55
Richard Robinson rick@robinsonhq.com
Version 1.1
05.01.2016
"""
import os
import usb.core
import usb.util as util
from array import array
import sys, argparse
 
dev = None
 
VID = 0x0c45
PID = 0x7406
 
# define HID constants
 
REQ_HID_GET_REPORT   = 0x01
REQ_HID_GET_IDLE     = 0x02
REQ_HID_GET_PROTOCOL = 0x03
 
REQ_HID_SET_REPORT   = 0x09
REQ_HID_SET_IDLE     = 0x0A
REQ_HID_SET_PROTOCOL = 0x0B
 
HID_REPORT_TYPE_INPUT   = 1<<8
HID_REPORT_TYPE_OUTPUT  = 2<<8
HID_REPORT_TYPE_FEATURE = 3<<8
 
def openDev():
    global dev
    dev = usb.core.find(idVendor=VID, idProduct=PID)
    if dev is None:
        print >> sys.stdout, "Device not Found - is the scale plugged into the USB port?"
        sys.stdout.flush()
    if dev.is_kernel_driver_active(0):
        dev.detach_kernel_driver(0)
    dev.set_configuration() # do reset and set active conf. Must be done before claim.
#    util.claim_interface(dev, None)
#    print >> sys.stdout, "Configuration set"
 
def setReport(reportId, data):
    r = dev.ctrl_transfer(
        util.build_request_type(util.CTRL_OUT, util.CTRL_TYPE_CLASS, util.CTRL_RECIPIENT_INTERFACE), # bmRequestType,
        REQ_HID_SET_REPORT,
        HID_REPORT_TYPE_OUTPUT | reportId,
        0,                 # feature_interface_num
        data,              # data
        1000               # timeout (1000 was too small for C_FREE)
    )
    return r
 
def read():
    openDev()
    try:
        dev.read(0x81,128) #flush 
    except usb.core.USBError:
        pass
    #open device ready to receive data     
    setReport(9, array('B',(0xAA,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4)))
    try:
        dev.read(0x81,128) #flush 
    except usb.core.USBError:
        pass
    # Not sure if this is necessary but the response return the following 
    # string in ascii over 32 bytes:
    # Andon Blood Pressure Meter KD
    setReport(9, array('B',(0xA4,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4)))
    x = dev.read(0x81,8)
    setReport(9, array('B',(0xA5,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4)))
    x = dev.read(0x81,8)
    setReport(9, array('B',(0xA6,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4)))
    x = dev.read(0x81,8)
    setReport(9, array('B',(0xA7,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4)))
    x = dev.read(0x81,8)
    # First proper data - first byte contains the number of readings stored
    setReport(9, array('B',(0xA2,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4)))
    x = dev.read(0x81,8)
    y = x[0]
    for i in xrange(y):
        setReport(9, array('B',(0xA3,i+1,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4)))
        x = dev.read(0x81,8)
    # Year AND Heart Arrhythmia
        if x[7]>=128:
            arrhythmia = True
            year = str(x[7]-128 +2000)
        else:
            arrhythmia = False
            year = str(x[7]+2000)
    # Month AND  Resting Indicator
        if x[3]>=128:
            rest = True
            month = str(x[3]-128)
        else:
            rest = False
            month = str(x[3])
    # Day and User
        if x[4]>=128:
            user = 'B'
            day = str(x[4]-128)
        else:
            user = 'A'
            day = str(x[4])
        date = year+'-'+month+'-'+day
        if user == args.user:
    #DATA
            sys.stdout.write('DATA:')
    #Date
            sys.stdout.write(date + args.delimeter)
    # Hour AND UNKNOWN
            if x[5]>=128:
                sys.stdout.write('\n' + 'ERROR - Hour has first bit set on')
            else:
                hour = str(x[5])
    # Minute AND UNKNOWN
            if x[6]>=128:
                sys.stdout.write('\n' + 'ERROR - Hour has first bit set on')
            else:
                minute = str(x[6])
            time = hour+':'+minute
    #Time
            sys.stdout.write(time + args.delimeter)
    # Systolic Pressure
            sys.stdout.write(str(x[0]+25)+args.delimeter)
    # Diastolic Pressure
            sys.stdout.write(str(x[1]+25)+args.delimeter)
    # Pulse Rate
            sys.stdout.write(str(x[2])+args.delimeter)
    # User
            sys.stdout.write(user+args.delimeter)
    # Resting Indicator
            sys.stdout.write(str(rest)+args.delimeter)
    # Arrhythia
            sys.stdout.write(str(arrhythmia)+'\n')
    sys.stdout.flush()
    setReport(9, array('B',(0xF7,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4)))
    try:
        dev.read(0x81,128) #flush 
    except usb.core.USBError:
        pass
    setReport(9, array('B',(0xF6,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4,0xF4)))
    try:
        dev.read(0x81,128) #flush 
    except usb.core.USBError:
        pass
def main():
    #Direct all stderr to null in order that the calling java prog will only see the data and the "error strings" I generate
#    f = open(os.devnull, 'w')
#    sys.stderr = f

    parser = argparse.ArgumentParser(description="beurerbm55.py - Beurer BM-55 Blood Pressure Monitor data downloader (c) 2015 rick@robinsonhq.com")
    parser.add_argument("user", help="Specify for which the user the data should be downloaded", choices=["A", "B"])
    parser.add_argument("delimeter", help="specify the delimeter to be used to separate the data")
    global args
    args=parser.parse_args()
    

    print >> sys.stdout, "START"
    sys.stdout.flush()
    s = read()
    print >> sys.stdout, "END"
    sys.stdout.flush()


if __name__ == '__main__':
    main()
